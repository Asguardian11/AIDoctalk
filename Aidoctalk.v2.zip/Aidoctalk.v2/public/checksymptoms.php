<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Check Symptoms | AiDocTalk</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="styles.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  
</head>
<body>

  <div class="navbar" >
    <a href="index.php"> <button class="button1">⬅</button></a>  
    <h1 class="h1" >Check Symptoms</h1> 
    <i class="fas fa-bell"></i> 
  </div>

  <div class="page">
    <!-- Symptom Checker Input -->
    <div class="input-group">
      <input type="text" placeholder="Describe your symptoms" />
      <button>Check</button>
    </div>

    <!-- Info Cards -->
    <div class="card-grid">
      <div class="card">
        <h4>Common Symptoms</h4>
        <p>Browse a list of common symptoms</p>
      </div>
      <div class="card">
        <h4>Symptom Severity</h4>
        <p>Learn when to seek medical help</p>
      </div>
      <div class="card">
        <h4>FAQs on Symptoms</h4>
        <p>Get answers to symptom-related questions</p>
      </div>
    </div>

    <!-- Symptom Tracking -->
    <div class="tracking-title">Symptom Tracking</div>
    <p style="margin-bottom: 10px; text-align: center;">Log your symptoms and track your health over time.</p>

    <div class="clinic-search">
      <input type="text" placeholder="Find Clinics" />
      <button>Find Clinics</button>
    </div>
  </div>

</body>
</html>