<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AiDocTalk || First Aids </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    
  <div class="navbar">
    <a href="index.php"><button class="backButton" >⬅</button></a>
    <h1>Ask Doctor AI </h1>
    <i class="fas fa-bell"></i>
  </div>
  

    <div class="space">

    </div>

    
  <main class="main1" >
    <section class="tip">
      <h2>1. Bleeding</h2>
      <p>Apply firm pressure to the wound with a clean cloth or bandage. Elevate the injured part above heart level if possible. If bleeding doesn’t stop, seek medical help.</p>
    </section>

    <section class="tip">
      <h2>2. Burns</h2>
      <p>Cool the burn under running water for 10–15 minutes. Do not apply ice or butter. Cover the burn with a clean, non-stick bandage. Seek help if severe.</p>
    </section>

    <section class="tip">
      <h2>3. Choking</h2>
      <p>If the person can't breathe, perform the Heimlich maneuver. Stand behind them, wrap your arms around their waist, and give quick inward thrusts above the navel.</p>
    </section>

    <section class="tip">
      <h2>4. CPR (Cardiopulmonary Resuscitation)</h2>
      <p>Check for breathing. If none, call emergency services. Begin chest compressions at the center of the chest—30 compressions followed by 2 rescue breaths. Repeat.</p>
    </section>

    <section class="tip">
      <h2>5. Fractures</h2>
      <p>Immobilize the area. Apply a splint if trained. Don’t try to straighten the limb. Keep the person calm and seek emergency help.</p>
    </section>

    <section class="tip">
      <h2>6. Heatstroke</h2>
      <p>Move the person to a cool place. Remove excess clothing. Apply cool, wet cloths and give sips of water. Call emergency services if unconscious or confused.</p>
    </section>

    <section class="tip">
      <h2>7. Seizures</h2>
      <p>Don’t restrain the person. Clear the area of dangerous objects. Turn them onto their side after the seizure. Seek help if it lasts more than 5 minutes.</p>
    </section>
  </main>

  <footer class="foot" >
    <p>&copy; 2025 Aidoctalk. This page provides general first aid advice. Always consult a professional in an emergency.</p>
  </footer>
    
</body>
</html>