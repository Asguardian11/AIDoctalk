<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AiDocTalk || First Aid </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
   <div class="navbar">
      <a href="index.php"> <button>⬅</button> </a>
      <h1> Health Tips</h1>
      <i class="fas fa-bell"></i>
    </div>
        
        

        
  <main class="mmain" >
    <h2>Top Tips for a Healthier Life</h2>

    <div class="tipp">
      <h3>1. Stay Hydrated</h3>
      <p>Drink at least 8 glasses of water a day to maintain body function and flush out toxins.</p>
    </div>

    <div class="tipp">
      <h3>2. Get Regular Exercise</h3>
      <p>Engage in at least 30 minutes of physical activity daily to improve heart health and mood.</p>
    </div>

    <div class="tipp">
      <h3>3. Eat a Balanced Diet</h3>
      <p>Include more fruits, vegetables, and whole grains in your meals. Limit sugar and processed foods.</p>
    </div>

    <div class="tipp">
      <h3>4. Sleep Well</h3>
      <p>Aim for 7-9 hours of sleep every night to allow your body to rest and recover.</p>
    </div>

    <div class="tipp">
      <h3>5. Manage Stress</h3>
      <p>Practice mindfulness, deep breathing, or yoga to keep stress levels under control.</p>
    </div>

  </main>

  <footer class="footer12">
    &copy; 2025 AiDocTalk - Stay Healthy, Stay Informed
  </footer>

</body>
</html>




