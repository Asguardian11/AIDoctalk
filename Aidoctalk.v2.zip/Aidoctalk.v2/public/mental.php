<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AiDocTalk || First Aid </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="navbar">  
        <a href="index.php"> <button>⬅</button> </a>
        <h1>Mental Health Help</h1>
        <i class="fas fa-bell"></i>
    </div>
    <div class="space">

    </div>

    <section class="intro">
        <h2>What Is Mental Health?</h2>
        <p>Mental health is just as important as physical health. At <strong>AiDocTalk</strong>, we provide support, guidance, and resources to help you take care of your mental well-being.</p>
    </section>

    <section class="help">
        <h2>How We Can Help</h2>
        <ul>
            <li>✅ <strong>Self-Assessment Tools</strong> – Check in with your emotions and mental health.</li>
            <li>✅ <strong>AI-Powered Support</strong> – Get AI-driven suggestions for stress management.</li>
            <li>✅ <strong>Find Nearby Specialists</strong> – Locate professional therapists and mental health clinics.</li>
            <li>✅ <strong>Immediate Coping Strategies</strong> – Practical tips to handle anxiety and stress.</li>
            <li>✅ <strong>Emergency Help</strong> – Find crisis support and emergency contacts.</li>
        </ul>
    </section>

    <section class="concerns">
        <h2>Common Mental Health Concerns</h2>
        <ul>
            <li>🧠 <strong>Stress & Anxiety</strong> – Learn techniques to manage daily pressures.</li>
            <li>🧠 <strong>Depression</strong> – Find support and self-care strategies.</li>
            <li>🧠 <strong>Sleep Disorders</strong> – Tips for better rest and relaxation.</li>
            <li>🧠 <strong>Emotional Well-being</strong> – Discover ways to maintain a positive outlook.</li>
        </ul>
    </section>

    <section class="priority">
        <h2>Your Health, Our Priority</h2>
        <p>You’re not alone. Mental health matters, and support is available. Explore resources, seek guidance, and take small steps toward well-being. Your mind deserves care.</p>
        <p><strong>Need help now?</strong> Find professional support and emergency contacts here: <a href="emergency.php">Emergency Numbers</a></p>
    </section>

    <footer class="footer2" >
        <p>© 2025 AiDocTalk | Mental Health Support</p>
    </footer>
    
</body>
</html>


