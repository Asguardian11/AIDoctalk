<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AiDocTalk || FAQs </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <style>

main {
      max-width: 900px;
      margin: auto;
      padding: 20px;
    }
    h2 {
      color: black;
      border-bottom: 2px solid #0aa83f;
      padding-bottom: 5px;
    }
    .review {
      background-color: white;
      border-radius: 8px;
      padding: 15px;
      margin: 15px 0;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    .review h3 {
      margin: 0;
      font-size: 16px;
      color: #333;
    }
    .review p {
      margin: 5px 0 0;
      color: #555;
    }
    form {
      font-weight: bold;
      background: white;
      padding: 15px;
      margin-top: 30px;
      border-radius: 8px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    form input, form textarea, form button {
      width: 100%;
      padding: 10px;
      margin-top: 10px;
      border-radius: 5px;
      border: 1px solid #ccc;
      font-size: 14px;
    }
    form button {
      background-color:#0aa83f ;
      color: white;
      border: none;
      cursor: pointer;
      font-weight: bold;
    }
    form button:hover {
      background-color: #009970;
    }


  button {
      background-color: transparent;
      color: white;
      border: none;
      padding: 15px 30px;
      font-size: 26px;
      border-radius: 8px;
      cursor: pointer;
      width: 100%;
    }
    
    button:hover {
      background-color: #059c50;
    }
    .navbar {
      background-color: #0aa83f;
      color: white;
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    body{
        margin:0;
        font-weight: bold;
    }

    footer {
      text-align: center;
      padding: 10px;
      font-size: 14px;
      background: #e0f7f2;
    }
    .navbar h1 {
      margin: 0;
      font-size: 24px;
    }

    .navbar i {
      font-size: 20px;
      cursor: pointer;
    }

    </style>
</head>
<body>
    <div class="navbar">  
        <a href="index.php"> <button>⬅</button> </a>
        <h1> Review Page</h1>
        <i class="fas fa-bell"></i>
    </div>

    

    <main>
    <h2>Recent Reviews</h2>

    <div class="review">
      <h3>Sadiq Ibrahim. Abuja</h3>
      <p>This app really helped me find nearby hospitals quickly. Very useful and easy to use!</p>
    </div>

    <div class="review">
      <h3>Emeka O.</h3>
      <p>I love the AI chatbot. It gave me helpful advice when I had a fever. Thank you NaijaHealth Buddy!</p>
    </div>

    <div class="review">
      <h3>Aisha YM. </h3>
      <p>Clean interface and fast. Keep up the good work!</p>
    </div>

    <form>
      <h2>Leave a Review</h2>
      <input type="text" placeholder="Your Name" required>
      <input type="mail" placeholder="Your Email" required>
      <textarea rows="4" placeholder="Write your review..." required></textarea>
      <button onclick="submitReview()" type="submit">Submit Review</button>
    </form>
  </main>



  <footer>
    &copy; 2025 AiDocTalk - Your Voice Matters
  </footer>

  <script src="script.js"></script>
</body>
</html>


