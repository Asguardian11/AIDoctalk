<?php
// api.php

header('Content-Type: application/json');

// Get the POSTed JSON data
$input = json_decode(file_get_contents('php://input'), true);

if (!isset($input['message']) || empty(trim($input['message']))) {
    http_response_code(400);
    echo json_encode(['error' => 'No message provided']);
    exit;
}

$userMessage = trim($input['message']);

// Your OpenRouter API key here
$apiKey = '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';

// OpenRouter API endpoint
$apiUrl = 'https://openrouter.ai/api/v1/chat/completions';

// Prepare the data payload according to OpenRouter spec
$data = [
    "model" => "openai/gpt-4o-mini",
    "messages" => [
        ["role" => "user", "content" => $userMessage]
    ],
    "max_tokens" => 500,
];

// Initialize cURL
$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'Authorization: Bearer ' . $apiKey,
]);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

// Execute request
$response = curl_exec($ch);
$httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if (curl_errno($ch)) {
    http_response_code(500);
    echo json_encode(['error' => 'Request error: ' . curl_error($ch)]);
    curl_close($ch);
    exit;
}

curl_close($ch);

if ($httpcode !== 200) {
    http_response_code($httpcode);
    echo $response;
    exit;
}

// Decode API response
$result = json_decode($response, true);

// Extract AI reply
$aiReply = '';
if (isset($result['choices'][0]['message']['content'])) {
    $aiReply = $result['choices'][0]['message']['content'];
} else {
    $aiReply = "Sorry, I couldn't get a response.";
}

echo json_encode(['reply' => $aiReply]);
