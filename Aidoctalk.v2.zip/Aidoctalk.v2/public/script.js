const chatBox = document.getElementById('chat-box');
const userInput = document.getElementById('user-input');

function appendMessage(text, className) {
  const div = document.createElement('div');
  div.classList.add('message', className);
  div.textContent = text;
  chatBox.appendChild(div);
  chatBox.scrollTop = chatBox.scrollHeight;
}

async function sendMessage() {
  const message = userInput.value.trim();
  if (!message) return;

  appendMessage(message, 'user');
  userInput.value = '';

  try {
    const response = await fetch('chatbot.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message }),
    });

    const data = await response.json();

    if (response.ok) {
      appendMessage(data.reply, 'bot');
    } else {
      appendMessage('Error: ' + (data.error || 'Failed to get response'), 'bot');
    }
  } catch (error) {
    appendMessage('Network error. Please try again.', 'bot');
  }
}
