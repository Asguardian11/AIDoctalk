<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AiDocTalk || Home </title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="styles.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  <style>

  </style>
  <!-- Icons -->
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>

  <div class="navbar">
    <h1>AIDocTalk </h1>
    <i class="fas fa-bell"></i>
  </div>

  <div class="container">
    <div class="welcome">
      <div class="ai-avatar">
        <i class="fas fa-robot"></i>
      </div>
      <div class="speech">
        <p>Your Health <br>
           &nbsp; &nbsp;&nbsp; Our Priority<br> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
           Health Assistant!</p>
      </div>
    </div>

    <div class="grid">
    <a href="Ai.php"><div class="grid-item"><i class="fas fa-comment-medical"></i><p>Ask Doctor AI</p></div></a>
     <a href="findClinic.php"> <div class="grid-item"><i class="fas fa-hospital"></i><p>Find Clinics</p></div></a>
      <a href="checksymptoms.php"><div class="grid-item"><i class="fas fa-stethoscope"></i><p>Check Symptoms</p></div></a>
      <a href="firstAid.php"><div class="grid-item"><i class="fas fa-first-aid"></i><p>First Aid Tips</p></div></a>
      <a href="mental.php"><div class="grid-item"><i class="fas fa-brain"></i><p>Mental Health Help</p></div></a>
      <a href="emergency.php"><div class="grid-item"><i class="fas fa-phone-alt"></i><p>Emergency Numbers</p></div></a>
      <a href="healthtips.php"> <div class="grid-item"><i class="fas fa-notes-medical"></i><p>Health Tips</p></div> </a>
      <a href="faqs.php"><div class="grid-item"><i class="fas fa-question-circle"></i><p>FAQs</p></div></a>
    </div>
  </div>
    <a href="review.php">
  <button class="chat-btn">
    <i class="fas fa-comment-dots"></i>
  </button>
  </a>
  <!-- Footer -->

  
  <h2 style="margin-left: 15px;" >6 Reasons Why Choose AIDocTalk</h2>
  <div class="footer">
    
    <div class="flexx">
    <p>✅ Instant Health Guidance</p>
    <p>✅ Accurate AI-Powered Suggestions</p>
    <p>✅ Find Nearby Clinics & Emergency Numbers</p></div>
    
    <div class="flexx">
    <p>✅ Mental Health Support</p>
    <p>✅ First Aid Tips & FAQs</p>
    <p>✅ Your Health, Our Priority!</p>
  </div>
  </div>

</body>
</html>