<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AiDocTalk || FAQs </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="navbar">  
        <a href="index.php"> <button>⬅</button> </a>
        <h1> FAQs</h1>
        <i class="fas fa-bell"></i>
    </div>

    
    
  <main class="main1" >
    <h2>General Health FAQs</h2>

    <div class="faq">
      <h3>1. How often should I go for a medical checkup?</h3>
      <p>It’s recommended to have a full medical checkup once a year, especially if you’re over 30 or have a chronic condition.</p>
    </div>

    <div class="faq">
      <h3>2. What are common symptoms of malaria?</h3>
      <p>Common symptoms include fever, chills, headache, nausea, and body aches. Seek medical help if you suspect malaria.</p>
    </div>

    <div class="faq">
      <h3>3. Can I get health advice online?</h3>
      <p>Yes, basic advice can be provided online by AI tools or professionals, but always consult a doctor for serious issues.</p>
    </div>

    <div class="faq">
      <h3>4. How can I tell if a headache is serious?</h3>
      <p>If it’s sudden, very severe, or comes with vision problems or confusion, seek immediate medical attention.</p>
    </div>

    <div class="faq">
      <h3>5. What’s the best way to boost immunity?</h3>
      <p>Eat a balanced diet, get enough sleep, manage stress, exercise regularly, and stay hydrated.</p>
    </div>

  </main>

  <footer class="footer12" >
    &copy; 2025 NaijaHealth Buddy - Empowering Health Awareness
  </footer>

</body>
</html>





