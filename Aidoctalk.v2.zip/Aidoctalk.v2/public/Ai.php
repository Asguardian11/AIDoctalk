<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AiDocTalk || Home </title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="styles.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  
  <!-- Icons -->
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>

  <div class="navbar">
    <a href="index.php"><button class="backButton" >⬅</button></a>
    <h1>Ask Doctor AI </h1>
    <i class="fas fa-bell"></i>
  </div>
  
  <div class="cont">
<div class="contt">
  <h2 class="h2" > NOTE: Advise Only.</h2>

  <div class="chat-container" id="chat-box">
    <!-- Messages will be appended here -->
  </div>

  <div class="input-area">
    <textarea id="user-input" rows="1" placeholder="Ask your health question..."></textarea>
    <button onclick="sendMessage()">Send</button>
  </div>
  </div>
</div>

  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <script src="script.js"></script>

</body>
</html>