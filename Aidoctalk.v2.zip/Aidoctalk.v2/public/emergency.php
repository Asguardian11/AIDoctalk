<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AiDocTalk || First Aid </title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="navbar">  
        <a href="index.php"> <button>⬅</button> </a>
        <h1>Emergency Numbers</h1>
        <i class="fas fa-bell"></i>
    </div>

    <div class="container">
        <header>
            <h1>Emergency Numbers</h1>
            <h2>Keep these important numbers handy in case of emergency.<h2>
        </header>
        <main>
            <table>
                <tr>
                    <th>Service</th>
                    <th>Emergency Number</th>
                </tr>
                <tr>
                    <td>General Emergency</td>
                    <td>112, 122</td>
                </tr>
                <tr>
                    <td>Police (NPF)</td>
                    <td>112, 911, 0803 303 3903</td>
                </tr>
                <tr>
                    <td>Fire Service</td>
                    <td>0705 999 9999</td>
                </tr>
                <tr>
                    <td>Medical Emergency.</td>
                    <td>112</td>
                </tr>
                <tr>
                    <td>FRSC</td>
                    <td>122, 0807 769 0365</td>
                </tr>
                <tr>
                    <td>SEMA</td>
                    <td>0704 444 4444</td>
                </tr>
                <tr>
                    <td>Child Helpline</td>
                    <td>0800 123 1234</td>
                </tr>
                <tr>
                    <td>Hisbah Board</td>
                    <td> 0803 661 1807</td>
                </tr>
                <tr>
                    <td>Human Rights</td>
                    <td>0800 647 4245</td>
                </tr>
                <tr>
                    <td>Disaster Aid</td>
                    <td>0803 409 2331</td>
                </tr>
            </table>
        </main>
        <footer>
            <p>© 2025 Aidoctalk. All rights reserved.</p>
        </footer>
    </div>

    
</body>
</html>













