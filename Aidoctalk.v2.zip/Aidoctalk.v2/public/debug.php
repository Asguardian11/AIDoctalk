<?php
// debug.php

header('Content-Type: application/json');

$raw = file_get_contents('php://input');

if (empty($raw)) {
    echo json_encode(['error' => 'No input received']);
    exit;
}

$data = json_decode($raw, true);

if ($data === null) {
    echo json_encode(['error' => 'Invalid JSON', 'raw' => $raw]);
    exit;
}

if (!isset($data['message']) || trim($data['message']) === '') {
    echo json_encode(['error' => 'No message provided', 'raw' => $raw]);
    exit;
}

echo json_encode(['success' => true, 'message' => $data['message']]);
