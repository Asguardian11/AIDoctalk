
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Nearby Hospital Finder - Kano</title>

  <!-- Leaflet CSS -->
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.3/dist/leaflet.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <link rel="stylesheet" href="styles.css">
  <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
  
  <style>
    
    button {
      background-color:white ;
      color: #0aa83f;
      border: 3px solid #0aa83f;
      padding: 15px 30px;
      font-size: 26px;
      border-radius: 8px;
      cursor: pointer;
      width: 100%;
    }

    
    button:hover {
      background-color:#0aa83f;
      color: white;
    }
    
    h1{
      position: absolute;
      left: 50%;
      transform: translateX(-50%);
    }
    header {
      background-color: #0aa83f;
      color: white;
      position: relative;
      padding: 20px 40px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    #controls {
      text-align: center;
      padding: 10px;
    }

    #map {
      height: 70vh;
      width: 100%;
    }

    @media (max-width: 600px) {
      #map {
        height: 60vh;
      }

      button {
        width: 100%;
      }
    }
  </style>
</head>
<body>
<div class="navbar">
  <a href="index.php"><button>⬅</button></a>
  <h1> Find Clinics</h1>
  <i class="fas fa-bell"></i>

</div>

<div id="controls">
  <button onclick="getUserLocation()">Find Hospitals Near Me</button>
</div>

<div id="map"></div>

<!-- Leaflet JS -->
<script src="https://unpkg.com/leaflet@1.9.3/dist/leaflet.js"></script>

<script>
  const apiKey = "20bb310e06fd4971a337373965b59bcf"; // Replace this

  let map;
  let userMarker;

  // Default location: Kano, Nigeria
  const defaultLat = 12.0022;
  const defaultLng = 8.5919;
  function initMap(lat = defaultLat, lng = defaultLng) {
    if (!map) {
        map = L.map('map').setView([lat, lng], 13);
        L.tileLayer(`https://maps.geoapify.com/v1/tile/osm-bright/{z}/{x}/{y}.png?apiKey=${apiKey}`, {  // ✅ Backticks used
            attribution: '&copy; OpenStreetMap contributors | Geoapify',
            maxZoom: 20,
        }).addTo(map);
    } else {
        map.setView([lat, lng], 13);
    }
}


  function getUserLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        position => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;

          initMap(lat, lng);

          if (userMarker) {
            map.removeLayer(userMarker);
          }

          userMarker = L.marker([lat, lng]).addTo(map).bindPopup("You are here").openPopup();

          findHospitals(lat, lng);
        },
        error => {
          alert("Could not get your location. Showing default (Kano).");
          findHospitals(defaultLat, defaultLng);
        }
      );
    } else {
      alert("Geolocation not supported. Showing default (Kano).");
      findHospitals(defaultLat, defaultLng);
    }
  }

  function findHospitals(lat, lng) {
    const radius = 5000;
    const url = `https://api.geoapify.com/v2/places?categories=healthcare.hospital&filter=circle:${lng},${lat},${radius}&bias=proximity:${lng},${lat}&limit=20&apiKey=${apiKey}`; // ✅ Corrected URL format

    fetch(url)
      .then(res => res.json())
      .then(data => {
        if (!data.features.length) {
          alert("No hospitals found nearby.");
          return;
        }

        data.features.forEach(hospital => {
          const coords = hospital.geometry.coordinates;
          const name = hospital.properties.name || "Unnamed Hospital";

          L.marker([coords[1], coords[0]])
            .addTo(map)
            .bindPopup(`<strong>${name}</strong>`);  // ✅ Corrected HTML string format
        });
      })
      .catch(err => console.error("Error fetching hospitals:", err));
}


  // Load default map on Kano
  initMap();
  // Optionally auto-search hospitals in Kano when the page loads
  findHospitals(defaultLat, defaultLng);
</script>

</body>
</html>